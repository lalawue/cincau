//
// Copyright (c) 2021 lalawue
//
// This library is free software; you can redistribute it and/or modify it
// under the terms of the MIT license. See LICENSE for details.
//

const html = htm.bind(m);

// wiki client state and markdown data
WikiCnt = {
    instance: false,        // editor instance
    dir_path: "wiki/",      // dir prefix
    attrs: {
        d1: undefined,      // 1st dir
        d2: undefined,      // 2nd dir
        d3: undefined,      // 3rd dir
        f: "",              // filename
    },
    text: "",               // markdown text
}

// if markdown link prefix match dir_path, invoke route.prefix
WikiCnt.toHTML = function (plainText) {
    console.log("cnt to html");
    var text = plainText.replace(/\[([\s\S]*?)\]\(([\s\S]*?)\)/g, function (a, b, c) {
        if (c.indexOf(WikiCnt.dir_path) == 0) {
            const dir_len = WikiCnt.dir_path.length;
            return '[' + b + '](' + m.route.prefix + '/' + c.substring(dir_len) + ')';
        }
        return a;
    });
    return SimpleMDE.prototype.markdown(text);
}

// editor config
WikiCnt.config = function (node) {
    return {
        element: node,
        spellChecker: false,
        autosave: {
            enabled: true,
            unique_id: "wiki_cnt",
        },
        renderingConfig: {
            singleLineBreaks: false,
            codeSyntaxHighlighting: true,
        },
        toolbar: [
            "bold",
            "italic",
            "heading",
            "|",
            "quote",
            "unordered-list",
            "ordered-list",
            "|",
            "link",
            "image",
            "code",
            "|",
            "table",
            "horizontal-rule",
            "preview",
            "|",
            "undo",
            "redo",
            "guide",
        ],
        previewRender: WikiCnt.toHTML,
    }
}

function wikiPageLoad() {

    // URL for GET/POST markdown data
    function wikiURL(attrs) {
        const path = "/wikidata?d=" + (attrs.d == undefined ? "" : attrs.d) + "&f=" + attrs.f;
        console.log("URL: ", path);
        return path;
    }

    // is dir and fname equal
    function isSamePage(as) {
        const ws = WikiCnt.attrs;
        return as.d == ws.d && as.f == ws.f;
    }

    // view state
    const ViewStateEnum = {
        LOADING: 1,    // loading page data
        EMPTY: 2,      // no page data
        SHOW: 3,       // show page data
        EDIT: 4,       // edit page data
        SITEMAP: 5,    // site map data
    }

    // view state and data model
    var PageModel = {
        viewState: ViewStateEnum.LOADING,
        loadPage: function (attrs) {
            const vstate = PageModel.viewState
            WikiCnt.attrs = attrs;
            PageModel.viewState = ViewStateEnum.LOADING;
            if (vstate == ViewStateEnum.SITEMAP) {
                return m.request(wikiURL(attrs))
                    .then(function (ret) {
                        if (ret.errcode == 0) {
                            WikiCnt.text = ret.text;
                            PageModel.viewState = ViewStateEnum.SHOW;
                        } else {
                            WikiCnt.text = "";
                            PageModel.viewState = ViewStateEnum.EMPTY;
                        }
                    })
            } else {
                return m.request(wikiURL(attrs))
                    .then(function (ret) {
                        if (ret.errcode == 0) {
                            WikiCnt.text = ret.text;
                            PageModel.viewState = ViewStateEnum.SHOW;
                        } else {
                            WikiCnt.text = "";
                            PageModel.viewState = ViewStateEnum.EMPTY;
                        }
                    })
            }
        },
        savePage: function () {
            WikiCnt.text = WikiCnt.instance.value();
            PageModel.viewState = ViewStateEnum.LOADING;
            return m.request({
                method: "POST",
                url: wikiURL(WikiCnt.attrs),
                body: { text: WikiCnt.text },
            }).then(function (ret) {
                if (ret.errcode == 0) {
                    PageModel.viewState = ViewStateEnum.SHOW;
                } else {
                }
            })
        },
        editPage: function () {
            PageModel.viewState = ViewStateEnum.EDIT;
        },
        siteMap: function () {
            PageModel.viewState = ViewStateEnum.SITEMAP;
            m.route.set("/sitemap")
        }
    }

    var ContainerView = {
        view: function (vnode) {
            const attrs = vnode.attrs;
            var vstate = PageModel.viewState;
            if (!isSamePage(attrs)) {
                vstate = ViewStateEnum.LOADING;
            }
            switch (vstate) {
                case ViewStateEnum.SITEMAP:
                case ViewStateEnum.LOADING:
                    PageModel.loadPage(attrs);
                    return html`
                        <br/><br/><br/>
                        <div class="mx-auto center"><p>Loading...</p></div>
                    `
                case ViewStateEnum.EMPTY:
                    return html`
                        <br/><br/><br/>
                        <div class="mx-auto center">
                            <button id="create_btn" onclick="${PageModel.editPage}">Create Page</button>
                        </div>
                    `
                case ViewStateEnum.SHOW:
                    return m.trust(WikiCnt.toHTML(WikiCnt.text));
                case ViewStateEnum.EDIT:
                    return html`
                        <div id="text_area">
                            <textarea id="markdown_editor"></textarea>
                            <script>
                                WikiCnt.instance = new SimpleMDE(WikiCnt.config(document.getElementById("markdown_editor")));
                                WikiCnt.instance.value(WikiCnt.text);
                            </script>
                        </div>
                    `
            }
        }
    }

    // page title
    var TitleView = {
        view: function () {
            const as = WikiCnt.attrs;
            if (as.d == undefined) {
                return as.f;
            }
            return html`${as.f}<br/><span class="h5">${as.d}/</span>`
        }
    }

    // edit/save button
    var BtnView = {
        view: function () {
            console.log("btn view");
            switch (PageModel.viewState) {
                case ViewStateEnum.EDIT:
                    return html`
                        <button onclick="${PageModel.siteMap}">Map</button>
                        <br/>
                        <button id="btn_right" class="mt1" onclick="${PageModel.savePage}">Save</button>
                    `
                case ViewStateEnum.SHOW:
                    return html`
                        <button onclick="${PageModel.siteMap}">Map</button>
                        <br/>
                        <button id="btn_right" class="mt1" onclick="${PageModel.editPage}">Edit</button>
                    `;
                default:
                    return "";
            }
        }
    }

    // content container
    var main_container = document.getElementById('main_container');
    m.route(main_container, '/index', {
        '/:f': ContainerView,
        '/:d.../:f': ContainerView,
    })
    m.mount(document.getElementById('wiki_title'), TitleView);
    m.mount(document.getElementById('btn_right'), BtnView);

    console.log("page load")
}

wikiPageLoad();